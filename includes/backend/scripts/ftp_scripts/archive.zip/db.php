<?php

session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../../../database_connections/sabooks_plesk.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbh);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$plan = 1; // Replace this with the desired ID value

$userkey = $_SESSION['ADMIN_USERKEY'];

// SQL to select data
$sql = "SELECT * FROM plesk_accounts WHERE USERKEY = $userkey";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $user_id = $row["ID"];
    }
} else {
    echo "0 results";
}

$conn->close();


    $servername = "localhost";
    $username = "";
    $password = "";
    $dbh = "";

    //Create connection
    $con = new mysqli($servername, $username, $password, $dbh);

    //Check connection
    if($con->connect_error){
        die("Connection failed: ". $con->connect_error);
    }

?>