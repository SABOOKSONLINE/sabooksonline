<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$ftpHost = 'ftp.onerhosting.co.za';
$ftpUsername = 'oner_hostings';
$ftpPassword = '!Emmanuel@1632';

$localZipPath = '../website/files.zip';    // Path to the local zip file
$remoteZipPath = '/httpdocs/files.zip';    // Remote path for the zip file

$remoteExtractPath = '/httpdocs/extracted/'; // Remote path for extracted files

// Connect to the FTP server
$ftpConnection = ftp_connect($ftpHost);
if (!$ftpConnection) {
    die('Could not connect to the FTP server');
}

// Log in to the FTP server
$loginResult = ftp_login($ftpConnection, $ftpUsername, $ftpPassword);
if (!$loginResult) {
    die('FTP login failed');
}

// Upload the zip file
$uploadResult = ftp_put($ftpConnection, $remoteZipPath, $localZipPath, FTP_BINARY);
if (!$uploadResult) {
    die('File upload failed');
}

// Close the FTP connection
ftp_close($ftpConnection);

// Extract the zip file
$extracted = unzipFile($remoteZipPath, $remoteExtractPath);

if ($extracted) {
    echo 'File uploaded and extracted successfully.';
} else {
    echo 'Failed to extract the file.';
}

function unzipFile($zipFilePath, $extractPath)
{
    $zip = new ZipArchive;
    if ($zip->open($zipFilePath) === true) {
        if (!$zip->extractTo($extractPath)) {
            return false;
        }
        $zip->close();
        return true;
    } else {
        return false;
    }
}

?>
