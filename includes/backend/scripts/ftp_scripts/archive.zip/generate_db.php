<?php

session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../../../database_connections/sabooks_plesk.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbh);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$plan = 1; // Replace this with the desired ID value

$userkey = $_SESSION['ADMIN_USERKEY'];

// SQL to select data
$sql = "SELECT * FROM plesk_accounts WHERE USERKEY = $userkey";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $username = $row["USERNAME"];
        $password = $row["PASSWORD"];
    }
} else {
    echo "0 results";
}


$filePath = 'db.php'; // Replace with the desired file path

// Content to write to the file
$content = '
    <?php

        $servername = "localhost";
        $username = "'.$username.'";
        $password = "'.$password.'";
        $dbh = "'.$username.'";

        //Create connection
        $con = new mysqli($servername, $username, $password, $dbh);

        //Check connection
        if($con->connect_error){
            die("Connection failed: ". $con->connect_error);
        }

    ?>
';


if (file_put_contents($filePath, $content) !== false) {
    $db_success = true;

} else {
    $db_success = false;
    echo "An error occurred: " . $result->errtext;

}

$conn->close();

?>