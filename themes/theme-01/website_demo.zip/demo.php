<?php
$servername = "localhost";
/*$username = "root";
$password = "";
$dbh = "sabooksonline";*/

$username = "emmanuel";
$password = "!Emmanuel@1632";
$dbh = "Sibusisomanqa_website";

// Create connection
$demo_conn = new mysqli($servername, $username, $password, $dbh);

// Check connection
if ($demo_conn->connect_error) {
  die("Connection failed: " . $demo_conn->connect_error);
}
?>