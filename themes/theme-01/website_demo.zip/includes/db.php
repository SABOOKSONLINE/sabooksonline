<?php
$servername = "localhost";
/*$username = "root";
$password = "";
$dbh = "sabooksonline";*/

$username = "emmanuel";
$password = "!Emmanuel@1632";
$dbh = "Sibusisomanqa_website";

// Create connection
$con = new mysqli($servername, $username, $password, $dbh);

// Check connection
if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
}
?>